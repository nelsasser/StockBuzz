function TwitterGetter() {

}